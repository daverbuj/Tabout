from playsound import playsound

def soundit(sound_file):
	print(sound_file)
	playsound(sound_file)